import snowflake.connector as snow

# Gets the version
ctx = snow.connect(user="PBVIRANI",
   password="Patel@8732",
   account="pd06844.ap-south-1.aws",
   warehouse="DATALOADS",
   database="POC_DATASET",
   schema="POC_SCHEMA")
cs = ctx.cursor()
try:
    cs.execute("SELECT current_version()")
    one_row = cs.fetchone()
    print(one_row[0])
finally:
    cs.close()
ctx.close()