from airflow.decorators import dag, task
from datetime import datetime,timedelta

default_args = {
    'owner': 'PBVIRANI',
    'retries': 5,
    'retry_delay': timedelta(minutes=5)
}

@dag(
    dag_id="dag_with_taskflow_api_v1",
    default_args=default_args,
    start_date=datetime(2023, 2, 23), 
    schedule_interval='@daily'
)

def hello_world_etl():

    @task(multiple_outputs=True)
    def get_name():
        return {'first_name' : 'Prince',
                'last_name' : 'Virani'}
    
    @task()
    def get_age():
        return 22

    @task()
    def display(firstname,lastname,age):
        print(f"Hello I am {firstname} {lastname} and i am {age} years old")
    
    name_dic = get_name()
    age = get_age()
    display(firstname=name_dic['first_name'],lastname=name_dic['last_name'],age=age)


greet_dag = hello_world_etl()