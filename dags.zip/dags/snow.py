
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta


default_args = {
    'owner': 'prince virani',
    'depends_on_past': False,
    'start_date': datetime(2023, 3, 2),
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'example_dag',
    default_args=default_args,
    description='An example DAG',
    schedule_interval=timedelta(days=1),
    catchup=False
)

def fetch_data_from_snowflake():
    print("Hello")
    # import snowflake.connector as snow
    print("Prince")
    conn = snow.connect(user="PBVIRANI",
        password="Patel@8732",
        account="pd06844.ap-south-1.aws",
        warehouse="DATALOADS",
        database="POC_DATASET",
        schema="POC_SCHEMA")

    
    # # Execute a query and fetch the results
    # cursor = conn.cursor()
    # cursor.execute('Select * from stock_spec where stock_id = 1')
    # rows = cursor.fetchall()
    # print(rows)
    # # Close the connection
    # conn.close()

snowflake_task = PythonOperator(
    task_id='fetch_data_from_snowflake',
    python_callable=fetch_data_from_snowflake,
    dag=dag
)
