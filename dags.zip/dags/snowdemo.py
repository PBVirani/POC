import logging
from datetime import datetime, timedelta
import airflow
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow import DAG
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator



args = {"owner": "Airflow", "start_date": datetime(2021,3,22,17,15)}

dag = DAG(
    dag_id="snowflake_connector3", default_args=args, schedule_interval=None
)

query1 = [
    """select 1;""",
    """show tables;""",
]


def count1(**context):
    print("hello")


with dag:
    query1_exec = SnowflakeOperator(
        task_id="snowflake_task1",
        sql=query1,
        snowflake_conn_id="snowflake_conn",
    )

    count_query = PythonOperator(task_id="count_query", python_callable=count1)
query1_exec >> count_query